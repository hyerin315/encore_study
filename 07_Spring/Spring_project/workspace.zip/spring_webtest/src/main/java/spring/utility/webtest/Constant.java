package spring.utility.webtest;
 
public class Constant {
    public static final String driver="oracle.jdbc.driver.OracleDriver";
    public static final String url="jdbc:oracle:thin:@127.0.0.1:1521:XE";
    public static final String user="hr";
    public static final String passwd="hr";
}